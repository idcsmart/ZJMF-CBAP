<?php 

return [
	// 
	'res_idcsmart_common_error_act' => '错误的操作',
	'res_idcsmart_common_act_exception' => '操作异常,请稍后重试',
	'res_idcsmart_common_host_not_found' => '产品不存在',

];