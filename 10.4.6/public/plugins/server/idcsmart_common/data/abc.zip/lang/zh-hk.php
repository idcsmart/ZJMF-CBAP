<?php 

return [
	// 
	'res_idcsmart_common_error_act' => '錯誤的操作',
	'res_idcsmart_common_act_exception' => '操作异常，請稍後重試',
	'res_idcsmart_common_host_not_found' => '產品不存在',

];