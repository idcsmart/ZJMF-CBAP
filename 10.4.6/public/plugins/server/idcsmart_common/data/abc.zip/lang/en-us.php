<?php 

return [
	// 
	'res_idcsmart_common_error_act' => 'Wrong operation',
	'res_idcsmart_common_act_exception' => 'Operation exception, please try again later',
	'res_idcsmart_common_host_not_found' => 'Product does not exist',

];