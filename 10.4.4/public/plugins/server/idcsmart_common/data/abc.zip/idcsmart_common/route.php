<?php 

use think\facade\Route;

$origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';

# 前台,可登录不可登录的接口
Route::group('console/v1',function (){

	// 订购页面
    Route::get('product/:id/reidcsmart_common/order_page', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@orderPage");
    Route::get('product/:id/reidcsmart_common/image', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@imageList");
    Route::post('product/:id/reidcsmart_common/duration', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@getAllDurationPrice");
    Route::get('product/:id/reidcsmart_common/config_limit', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@getAllConfigLimit");
    Route::get('product/:id/reidcsmart_common/vpc_network/search', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@vpcNetworkSearch");
    Route::get('product/:id/reidcsmart_common/line/:line_id', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@lineConfig");

    // vnc
    Route::get('reidcsmart_common/:id/vnc', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@vncPage");


})->allowCrossDomain([
    'Access-Control-Allow-Origin'        => $origin,
    'Access-Control-Allow-Credentials'   => 'true',
    'Access-Control-Max-Age'             => 600,
])->middleware(\app\http\middleware\Check::class);

// 前台需要登录的接口
Route::group('console/v1',function (){
    
    Route::post('product/:id/reidcsmart_common/validate_settle', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@validateSettle");
	Route::get('reidcsmart_common', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@list");
	Route::get('reidcsmart_common/:id', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@detail");
	Route::get('reidcsmart_common/:id/part', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@detailPart");
	Route::get('reidcsmart_common/:id/status', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@status");
	Route::post('reidcsmart_common/:id/on', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@on");
	Route::post('reidcsmart_common/:id/off', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@off");
	Route::post('reidcsmart_common/:id/reboot', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@reboot");
	Route::post('reidcsmart_common/:id/hard_off', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@hardOff");
	Route::post('reidcsmart_common/:id/hard_reboot', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@hardReboot");
	Route::post('reidcsmart_common/:id/vnc', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@vnc");
	Route::post('reidcsmart_common/:id/reset_password', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@resetPassword");
	Route::post('reidcsmart_common/:id/rescue', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@rescue");
	Route::post('reidcsmart_common/:id/rescue/exit', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@exitRescue");
	Route::post('reidcsmart_common/:id/reinstall', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@reinstall");
	Route::get('reidcsmart_common/:id/chart', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@chart");
	Route::get('reidcsmart_common/:id/disk', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@disk");
	Route::post('reidcsmart_common/:id/disk/:disk_id/unmount', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@diskUnmount");
	Route::post('reidcsmart_common/:id/disk/:disk_id/mount', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@diskMount");
	Route::get('reidcsmart_common/:id/snapshot', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@snapshot");
	Route::post('reidcsmart_common/:id/snapshot', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@snapshotCreate");
	Route::post('reidcsmart_common/:id/snapshot/restore', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@snapshotRestore");
	Route::delete('reidcsmart_common/:id/snapshot/:snapshot_id', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@snapshotDelete");
	Route::get('reidcsmart_common/:id/backup', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@backup");
	Route::post('reidcsmart_common/:id/backup', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@backupCreate");
	Route::post('reidcsmart_common/:id/backup/restore', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@backupRestore");
	Route::delete('reidcsmart_common/:id/backup/:backup_id', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@backupDelete");
	Route::get('reidcsmart_common/:id/flow', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@flowDetail");
	Route::get('reidcsmart_common/:id/log', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@log");
	Route::get('reidcsmart_common/:id/image/check', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@checkHostImage");
	Route::post('reidcsmart_common/:id/image/order', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@createImageOrder");
	Route::get('reidcsmart_common/:id/remote_info', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@remoteInfo");
	Route::get('reidcsmart_common/:id/ip', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@ipList");
	Route::post('reidcsmart_common/:id/disk/price', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@calBuyDiskPrice");
	Route::post('reidcsmart_common/:id/disk/order', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@createBuyDiskOrder");
	Route::post('reidcsmart_common/:id/disk/resize', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@calResizeDiskPrice");
	Route::post('reidcsmart_common/:id/disk/resize/order', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@createResizeDiskOrder");

	// 这2个价格有问题
	Route::get('reidcsmart_common/:id/backup_config', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@calBackupConfigPrice");
	Route::post('reidcsmart_common/:id/backup_config/order', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@createBackupConfigOrder");

	Route::get('reidcsmart_common/:id/ip_num', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@calIpNumPrice");
	Route::post('reidcsmart_common/:id/ip_num/order', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@createIpNumOrder");

	Route::post('reidcsmart_common/:id/vpc_network', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@createVpcNetwork");
	Route::get('reidcsmart_common/:id/vpc_network', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@vpcNetworkList");
	Route::put('reidcsmart_common/:id/vpc_network/:vpc_network_id', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@vpcNetworkUpdate");
	Route::delete('reidcsmart_common/:id/vpc_network/:vpc_network_id', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@vpcNetworkDelete");
	Route::put('reidcsmart_common/:id/vpc_network', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@changeVpcNetwork");
	Route::get('reidcsmart_common/:id/real_data', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@cloudRealData");

	Route::get('reidcsmart_common/:id/common_config', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@calCommonConfigPrice");
	Route::post('reidcsmart_common/:id/common_config/order', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@createCommonConfigOrder");

	// NAT转发建站
	Route::get('reidcsmart_common/:id/nat_acl', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@natAclList");
	Route::post('reidcsmart_common/:id/nat_acl', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@natAclCreate");
	Route::delete('reidcsmart_common/:id/nat_acl', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@natAclDelete");
	Route::get('reidcsmart_common/:id/nat_web', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@natWebList");
	Route::post('reidcsmart_common/:id/nat_web', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@natWebCreate");
	Route::delete('reidcsmart_common/:id/nat_web', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@natWebDelete");

	// 套餐升降级
	Route::get('reidcsmart_common/:id/recommend_config', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@getUpgradeRecommendConfig");
	Route::get('reidcsmart_common/:id/recommend_config/price', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@calUpgradeRecommendConfig");
	Route::post('reidcsmart_common/:id/recommend_config/order', "\\reserver\\idcsmart_common\\controller\\home\\CloudController@createUpgradeRecommendConfigOrder");

})->allowCrossDomain([
    'Access-Control-Allow-Origin'        => $origin,
    'Access-Control-Allow-Credentials'   => 'true',
    'Access-Control-Max-Age'             => 600,
])
->middleware(\app\http\middleware\CheckHome::class)
->middleware(\app\http\middleware\ParamFilter::class)
->middleware(\reserver\idcsmart_common\middleware\CheckAuthMiddleware::class);
    //->middleware(\app\http\middleware\RejectRepeatRequest::class);
