<?php
namespace reserver\idcsmart_common\validate;

use think\Validate;
use reserver\idcsmart_common\logic\ToolLogic;

/**
 * @title 下单参数验证
 * @use  reserver\idcsmart_common\validate\CartValidate
 */
class CartValidate extends Validate
{
	protected $rule = [
        'cpu'                => 'require|integer',
        'memory'             => 'require|integer',
        'bw'                 => 'integer',
        'flow'               => 'integer',
        'peak_defence'       => 'integer',
    ];

    protected $message  =   [
        'cpu.require'                   => 'res_idcsmart_common_cpu_require',
        'cpu.integer'                   => 'res_idcsmart_common_cpu_require',
        'memory.require'                => 'res_idcsmart_common_memory_require',
        'memory.integer'                => 'res_idcsmart_common_memory_require',
        'bw.integer'                    => 'res_idcsmart_common_bw_param_error',
        'flow.integer'                  => 'res_idcsmart_common_flow_param_error',
        'peak_defence.integer'          => 'res_idcsmart_common_peak_defence_param_error',
    ];

    protected $scene = [
        'upgrade_config' => ['cpu','memory','bw','flow','peak_defence'],
    ];

}